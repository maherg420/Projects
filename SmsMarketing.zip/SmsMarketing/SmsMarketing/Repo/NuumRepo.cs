﻿using SmsMarketing.Models;
namespace SmsMarketing.Repo
{
    class NuumRepo:GenericRepository<tbl_Number>
    {
    }
}
