﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using SmsMarketing.Models;
using SmsMarketing.Repo;
namespace SmsMarketing
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void SendSMS()
        {
            try
            {
                tbPhone.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                SerialPort sp = new SerialPort();
                sp.PortName = cbPort.Text;
                sp.Open();
                sp.WriteLine("AT" + Environment.NewLine);
                Thread.Sleep(100);
                sp.WriteLine("AT+CMGF=1" + Environment.NewLine);
                Thread.Sleep(100);
                sp.WriteLine("AT+CSCS=\"GSM\"" + Environment.NewLine);
                Thread.Sleep(100);

                sp.WriteLine("AT+CMGS=\"" + tbPhone.Text + "\"" + Environment.NewLine);
                Thread.Sleep(100);

                sp.WriteLine(tbMessage.Text + Environment.NewLine);
                Thread.Sleep(100);
                sp.Write(new byte[] { 26 }, 0, 1);
                Thread.Sleep(100);
                var response = sp.ReadExisting();
                if (response.Contains("ERROR"))
                {
                    MessageBox.Show("Sending failed", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show("sms send successfully..!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                sp.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet1.tbl_Number' table. You can move, or remove it, as needed.
            this.tbl_NumberTableAdapter.Fill(this.dataSet1.tbl_Number);
            lbrowCount.Text = "Total:" + dataGridView1.Rows.Count.ToString();
        }
        NuumRepo nr = new NuumRepo();
        private void SaveUpdate()
        {
            if (textBox1.Text == "")
            {
                if (tbPhone.Text != "")
                {
                    tbl_Number obj = new tbl_Number();
                    obj.Number = tbPhone.Text;
                    nr.Add(obj);
                   
                }
                else
                {
                    MessageBox.Show("Please enter your number to save in Software", "Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                IEnumerable<tbl_Number> tbl_s = nr.GetAll();
                foreach(var item in tbl_s)
                {
                    if(item.ID==decimal.Parse( textBox1.Text))
                    {
                        item.Number = tbPhone.Text;
                    }
                    nr.Update(item);
                }
            }
            dataGridView1.DataSource = nr.GetAll();
            newrec();
            lbrowCount.Text = "Total:" + dataGridView1.Rows.Count.ToString();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            SaveUpdate();
        }
        private void newrec()
        {
            tbPhone.Clear();
            tbMessage.Clear();
            textBox1.Clear();
          
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 0)
                {
                    SendSMS();
                }
                if (e.ColumnIndex == 1)
                {
                    DialogResult d = MessageBox.Show("Do you want to Delete this Record?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (d == DialogResult.Yes)
                    {
                        textBox1.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();

                        IEnumerable<tbl_Number> tb = nr.GetAll();

                        foreach (var item in tb)
                        {
                            if (item.ID == Convert.ToDecimal(textBox1.Text))
                            {
                                nr.DeleteRecord(item.ID);
                                dataGridView1.DataSource = nr.GetAll();
                                newrec();
                                lbrowCount.Text = "Total:" + dataGridView1.Rows.Count.ToString();
                            }
                        }

                    }
                }
                    if (e.ColumnIndex == 2)
                {
                    textBox1.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                    tbPhone.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                }
            }
            catch { }
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            SmsDBEntities ffe = new SmsDBEntities();
            if (tbSearch.Text != string.Empty)
            {
                var items = ffe.tbl_Number.Where(s => s.Number.Contains(tbSearch.Text));
                dataGridView1.DataSource = items.ToList();
                lbrowCount.Text = "Total " + dataGridView1.Rows.Count.ToString();
            }
            else
            {
                dataGridView1.DataSource = nr.GetAll();
                lbrowCount.Text = "Total " + dataGridView1.Rows.Count.ToString();
            }
        }
        private void sendAll()
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                SerialPort sp = new SerialPort();
                sp.PortName = cbPort.Text;
                sp.Open();
                sp.WriteLine("AT" + Environment.NewLine);
                Thread.Sleep(100);
                sp.WriteLine("AT+CMGF=1" + Environment.NewLine);
                Thread.Sleep(100);
                sp.WriteLine("AT+CSCS=\"GSM\"" + Environment.NewLine);
                Thread.Sleep(100);
                IEnumerable<tbl_Number> tbl_s = nr.GetAll();

                foreach (var item in tbl_s)
                {
                    sp.WriteLine("AT+CMGS=\"" + item.Number + "\"" + Environment.NewLine);
                    Thread.Sleep(100);
                }
                sp.WriteLine(tbMessage.Text + Environment.NewLine);
                Thread.Sleep(100);
                sp.Write(new byte[] { 26 }, 0, 1);
                Thread.Sleep(100);
                var response = sp.ReadExisting();
                if (response.Contains("ERROR"))
                {
                    MessageBox.Show("Sending failed", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show("sms send successfully..!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                sp.Close();
                Cursor.Current = Cursors.Default;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            sendAll();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode==Keys.Enter)
            {
                if(tbPhone.Text=="")
                {
                    sendAll();
                }
                else
                {
                    SaveUpdate();
                }
            }
        }
    }
}
